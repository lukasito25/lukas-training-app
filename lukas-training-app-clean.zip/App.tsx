import TrainingProgram from './TrainingProgram'

function App() {
  return <TrainingProgram />
}

export default App